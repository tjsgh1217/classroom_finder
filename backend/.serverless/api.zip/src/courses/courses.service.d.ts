export interface CourseWithTime {
    courseId: string;
    department: string;
    courseName: string;
    time: string;
    room: string;
}
export declare class CoursesService {
    private readonly db;
    private readonly TABLE;
    private readonly DAY_MAP_KR;
    private readonly DAY_MAP_EN;
    constructor();
    private parseSchedule;
    findCoursesByRoom(room: string): Promise<CourseWithTime[]>;
}
