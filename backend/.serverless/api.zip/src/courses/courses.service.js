"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoursesService = void 0;
const common_1 = require("@nestjs/common");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
let CoursesService = class CoursesService {
    db;
    TABLE = 'Courses';
    DAY_MAP_KR = {
        Mon: '월',
        Tue: '화',
        Wed: '수',
        Thu: '목',
        Fri: '금',
    };
    DAY_MAP_EN = {
        월: 'Mon',
        화: 'Tue',
        수: 'Wed',
        목: 'Thu',
        금: 'Fri',
    };
    constructor() {
        const client = new client_dynamodb_1.DynamoDBClient({ region: process.env.AWS_REGION });
        this.db = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
    }
    parseSchedule(row) {
        const timeParts = row.time.split('/');
        const roomParts = row.room.split('/');
        const schedule = [];
        let prevDayKr = null;
        let roomIdx = 0;
        for (const tp of timeParts) {
            const m = tp.match(/^([월화수목금])(\d+)$/);
            if (m) {
                const [, dayKr, period] = m;
                if (prevDayKr !== null && dayKr !== prevDayKr) {
                    roomIdx = Math.min(roomIdx + 1, roomParts.length - 1);
                }
                prevDayKr = dayKr;
                schedule.push({
                    day: this.DAY_MAP_EN[dayKr],
                    period,
                    room: roomParts[roomIdx],
                });
            }
            else {
                const last = schedule[schedule.length - 1];
                if (last) {
                    schedule.push({
                        day: last.day,
                        period: tp,
                        room: roomParts[roomIdx],
                    });
                }
            }
        }
        return schedule;
    }
    async findCoursesByRoom(room) {
        const { Items } = await this.db.send(new lib_dynamodb_1.ScanCommand({ TableName: this.TABLE }));
        const raw = Items;
        const withSched = raw.map(r => ({ ...r, schedule: this.parseSchedule(r) }));
        const filtered = withSched.filter(r => r.schedule.some(s => s.room === room));
        const result = [];
        for (const r of filtered) {
            const sched = r.schedule.filter(s => s.room === room);
            const dayGroups = {};
            sched.forEach(s => {
                (dayGroups[s.day] ||= []).push(s.period);
            });
            for (const [dayEn, periods] of Object.entries(dayGroups)) {
                result.push({
                    courseId: r.courseId,
                    department: r.department,
                    courseName: r.courseName,
                    time: `${this.DAY_MAP_KR[dayEn]}${periods.join('/')}`,
                    room,
                });
            }
        }
        return result;
    }
};
exports.CoursesService = CoursesService;
exports.CoursesService = CoursesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], CoursesService);
//# sourceMappingURL=courses.service.js.map