export declare class CoursesModule {
}
