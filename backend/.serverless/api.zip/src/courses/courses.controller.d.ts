import { CoursesService, CourseWithTime } from './courses.service';
export declare class CoursesController {
    private readonly svc;
    constructor(svc: CoursesService);
    byRoom(room: string): Promise<CourseWithTime[]>;
}
